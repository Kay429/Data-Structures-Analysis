
#include <iostream>
#include <string>
#include <fstream>
#include <vector>

using namespace std;


// Course struct
struct course {

       string courseNumber;
       string name;
       vector<string> prerequisites;

	   // Constructor
       course() {
           courseNumber = "noNumber";
           name = "noName";
       }

	   // Constructor that takes initial values for courseNumber and name
       course(string newCourseNumber, string newName) {
           courseNumber = newCourseNumber;
           name = newName;
       }

	   // Takes a string and appends it to prerequisites vector
       void appendPrerequisite(string prereq) {
           prerequisites.push_back(prereq);
       }
};

/**
 * Determines if the given line contains a comma
 * Throws an exception if there is no comma
 *
 * @param line - a string to be checked for commas
 */
void CommaCheck(string line) {
	bool hasComma = false;

	// Compare each character in line
	for (int i = 0; i < line.size(); ++i) {
		if (line[i] == ',') {
			hasComma = true;
			break;
		}
	}

	// If there is no comma, throw error no. 2
	if (hasComma == false) {
		throw 2;
	}
}

/**
 * Make sure all of the prerequisites for a course match an
 * existing course number in the courses vector
 *
 * @param courses - pointer to the vector containing all the courses
 * @param course - struct holding data for a single course
 */
void PrerequisiteCheck(vector<course>* courses, course course) {
	bool matchFound;

	// For each element of course's prerequisites
	for (int i = 0; i < course.prerequisites.size(); ++i) {
		matchFound = false;
		// For each course in the courses vector
		for (int j = 0; j < courses->size(); ++j) {
			if (courses->at(j).courseNumber == course.prerequisites[i]) {
				matchFound = true;
				break;
			}
		}
		// If no match is found, throw error no. 3
		if (!matchFound) {
			throw 3;
		}
	}
}

/**
 * Read from file
 * Create course objects from file and append them to courses
 * Perform CommaCheck and PrerequisiteCheck on the file's data
 *
 * @param file - pointer to the file ifstream
 * @param courses - pointer to the vector containing all the courses
 */
void ParseFile(ifstream* file, vector<course>* courses) {
	string currLine;
	vector<string> tempVector;
	string tempString;

	// Get lines until the end of the file is reached
	while (getline(*file, currLine)) {
		tempString = "";
		tempVector.clear();

		CommaCheck(currLine);

		// Split currLine into seperate strings
		for (int i = 0; i < currLine.size(); ++i) {
			if (currLine[i] != ',') {
				tempString.push_back(currLine[i]);
			}
			else {
				tempVector.push_back(tempString);
				tempString = "";
			}
		}
		tempVector.push_back(tempString); // Append final value of tempString

		course course(tempVector[0], tempVector[1]);

		// Add prerequisites from tempVector
		for (int i = 2; i < tempVector.size(); ++i) {
			course.appendPrerequisite(tempVector[i]);
		}

		courses->push_back(course);
	}

	// Once course vector is finished, perform prerequisite checks
	for (int i = 0; i < courses->size(); ++i) {
		PrerequisiteCheck(courses, courses->at(i));
	}
}

/**
 * Opens and parses file
 * Catches any errors in opening or parsing
 *
 * @param courses - pointer to the vector containing all the courses
 */
void OpenFile(vector<course>* courses) {
	bool fileRead = false;
	string userInput;

	while (fileRead == false) {
		ifstream file;
		string currLine;

		// Ask user which file to open
		cout << "What file would you like to open?" << endl;
		getline(cin, userInput);

		try {
			file.open(userInput);
			// If file cannot be opened, throw error no. 1
			if (!file.is_open()) {
				throw 1;
			}

			ParseFile(&file, courses);

			// If no exceptions were thrown, then reading from the file was successful
			fileRead = true;
			cout << endl << "The courses were loaded successfully." << endl << endl;
		}
		catch (int errorNum) {
			if (errorNum == 1) {
				cout << endl << "File could not be opened. Please try again." << endl << endl;
			}
			else if (errorNum == 2) {
				cout << endl << "The file could not be read." << endl << "One or more lines are missing a comma." << endl << endl;
			}
			else if (errorNum == 3) {
				cout << endl << "There is an error in the file." << endl << "One of the listed prerequisites is not in the course list." << endl << endl;
			}
			courses->clear();
			file.close();
		}
		file.close();
	}
}

/**
 * Partitions the vector into two parts
 *
 * @param courses - pointer to the vector containing all the courses
 * @param low - beginning index for partitioning
 * @param high - end index for partitioning
 */
int Partition(vector<course>* courses, int low, int high) {

	// Calculate midpoint and pivot
	int midpoint = low + (high - low) / 2;
	string pivot = courses->at(midpoint).courseNumber;

	bool done = false;

	// Runs until the vector is partitioned
	while (done == false) {
		// Until a value that needs to be swapped is found
		while (courses->at(low).courseNumber < pivot) {
			++low;
		}
		// Until a value that needs to be swapped is found
		while (pivot < courses->at(high).courseNumber) {
			--high;
		}
		// If low >= high, that means the entire vector has been traversed
		if (low >= high) {
			done = true;
		}
		else {
			swap(courses->at(low), courses->at(high));
			++low;
			--high;
		}
	}
	return high;

}

/**
 * Perform a quick sort
 *
 * @param courses - pointer to the vector containing all the courses
 * @param begin - beginning index for sorting
 * @param end - end index for sorting
 */
void QuickSort(vector<course>* courses, int begin, int end) {
	int mid = 0;

	// If begin is >= end, the partition is already sorted
	if (begin >= end) {
		return;
	}

	// Partition courses on either side of mid
	mid = Partition(courses, begin, end);

	// Recursively sort low partition (begin to mid)
	QuickSort(courses, begin, mid);

	// Recursively sort high partition (mid+1 to end)
	QuickSort(courses, mid + 1, end);

}

/**
 * Print all courses in the courses vector
 *
 * @param courses - pointer to the vector containing all the courses
 */
void PrintCourses(vector<course>* courses) {
	for (int i = 0; i < courses->size(); ++i) {
		cout << courses->at(i).courseNumber << ", " << courses->at(i).name << endl;
	}
}

/**
 * Print information about a single course
 * Print list of prerequisites
 *
 * @param course - struct representing a single course
 */
void PrintCourseInfo(course course) {
	cout << course.courseNumber << ", " << course.name << endl;
	cout << "Prerequisites: ";
	// If there are prerequisites, print them
	// Else just print "None"
	if (course.prerequisites.size() != 0) {
		for (int i = 0; i < course.prerequisites.size(); ++i) {
			cout << course.prerequisites[i];
			if (i != course.prerequisites.size() - 1) {
				cout << ", ";
			}
			else {
				cout << endl;
			}
		}
	}
	else {
		cout << "None" << endl;
	}
}

/**
 * Performs a binary search for a courseNumber that matches key
 * Prints information about course once found
 * If matching courseNumber is not found, informs user
 *
 * @param courses - pointer to the vector containing all the courses
 * @param key - a string used as a search key
 */
void BinarySearch(vector<course>* courses, string key) {
	int mid = 0;
	int low = 0;
	int high = courses->size() - 1;

	// Use mid to move high and low closer together,
	// narrowing down the options until a match is found
	// or high and low intersect
	while (high >= low) {
		// Each loop, mid is set between high and low
		mid = (high + low) / 2;
		if (courses->at(mid).courseNumber < key) {
			low = mid + 1;
		}
		else if (courses->at(mid).courseNumber > key) {
			high = mid - 1;
		}
		else {
			PrintCourseInfo(courses->at(mid));
			return;
		}
	}
	cout << "Sorry. \"" << key << "\" could not be found." << endl;
}

/**
 * Prints menu to screen
 */
void DisplayMenu() {
	cout << endl << "Welcome. What can I do for you today?" << endl;
	cout << "1. Load Courses" << endl;
	cout << "2. Print Course List" << endl;
	cout << "3. Search for Course" << endl;
	cout << "9. Exit" << endl << endl;
}

int main() {
	vector<course>courses;
	string userInput = "";

	DisplayMenu();

	while (userInput != "9") {
		cout << "Please input a number from the list: ";
		getline(cin, userInput);
		cout << endl;
		if (userInput == "1") {
			OpenFile(&courses);
			QuickSort(&courses, 0, courses.size() - 1);
			DisplayMenu();
		}
		else if (userInput == "2") {
			PrintCourses(&courses);
			cout << endl;
			DisplayMenu();
		}
		else if (userInput == "3") {
			cout << endl << "Please type the course number of the course you are looking for: ";
			getline(cin, userInput);
			cout << endl;
			BinarySearch(&courses, userInput);
			cout << endl;
			DisplayMenu();
		}
		// If user inputs 9, the loop will terminate
		// If user inputs anything else, the loop will start over and ask for new input
	}
	return 0;
}
